<?php
echo("de");
require_once 'model/conexaoMysql.php';
echo("deawd");